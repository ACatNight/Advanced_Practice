package org.acatNight.day9.test1;

public class Book {
    private String name;
    private double price;
    private int count;

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public int getCount() {
        return count;
    }

    public void showDetail() {
    }

    public void setAuthor(String author) {

    }
    public String getAuthor(){
        return "";
    }

    public void setIssue(String issue){

    }
    public String getIssue(){
        return "";
    }

    public void setField(String field){

    }
    public String getField(){
        return "";
    }

}